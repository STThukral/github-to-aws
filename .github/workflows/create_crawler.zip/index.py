import boto3
import os

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    glue = boto3.client('glue')

    # Get bucket name and file name from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_name = event['Records'][0]['s3']['object']['key']
    
    # Define Glue Crawler name
    crawler_name = 'crawler-' + file_name.replace('/', '-')

    # Get the Glue database name from the environment variable
    glue_database_name = os.environ['GLUE_DATABASE_NAME']
    
    # Define the S3 path for the crawler
    s3_path = f's3://{bucket_name}/{file_name}'

    # Define the Glue Crawler properties
    crawler = {
        'Name': crawler_name,
        'Role': os.environ['AWS_LAMBDA_ROLE_ARN'],  # IAM Role for Glue to access resources
        'DatabaseName': glue_database_name,
        'Targets': {
            'S3Targets': [
                {
                    'Path': s3_path,
                }
            ]
        },
        'Classifiers': [],
        'TablePrefix': 'csv_',
        # 'Schedule': 'cron(0 12 * * ? *)',  # Optional: Set up a schedule for the crawler
    }

    try:
        # Check if the crawler exists
        glue.get_crawler(Name=crawler_name)
        print(f"Crawler {crawler_name} already exists.")
    except glue.exceptions.EntityNotFoundException:
        # If the crawler doesn't exist, create it
        glue.create_crawler(**crawler)
        print(f"Crawler {crawler_name} created successfully.")

        # Start the crawler
        glue.start_crawler(Name=crawler_name)
        print(f"Crawler {crawler_name} started.")
        
         # Wait for the crawler to finish
        while True:
            response = glue.get_crawler(Name=crawler_name)
            crawler_status = response['Crawler']['State']
            if crawler_status == 'READY':
                print("Crawler Finished Successfully")
                break
            print(f"Crawler status: {crawler_status}, checking again in 10 seconds...")
            time.sleep(10)  # Wait for 10 seconds before checking again

        # Start Glue Job after Crawler completes
        print(f"Starting Glue Job: MyPySparkETLJob")
        response = glue_client.start_job_run(JobName='MyPySparkETLJob')  # Job name in single quotes
        print(f"Glue Job started with RunId: {response['JobRunId']}")


    return {
        'statusCode': 200,
        'body': f'Crawler {crawler_name} triggered successfully.'
    }
